// src/components/loader.js
export function Loader() {
  return `<div class="loader"><div class="spinner"></div></div>`;
}
