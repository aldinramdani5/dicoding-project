// src/components/chatbox.js
export function ChatboxWidget() {
  return `<!-- Chat-box -->
<div class="chat-box" id="chatBox">
  <!-- HEADER -->
  <div class="chat-header" id="chatHeader">
    <img
      src="https://cdn-icons-png.flaticon.com/512/1946/1946429.png"
      alt="Chat Icon"
    />
    <div>
      <h2>Halo Developers 👋</h2>
      <p>Terima kasih telah mengunjungi situs kami!</p>
    </div>
  </div>

  <!-- BODY -->
  <div class="chat-body" id="chatBody">
    <!-- Halaman Awal -->
    <div id="chatWelcome">
      <div class="chat-card">
        <h3>Kami sedang tidak tersedia saat ini</h3>
        <p>We will be back online at 08:00 AM</p>
        <button id="startChat">Mulai Percakapan</button>
      </div>

      <div class="articles">
        <h4>Artikel Populer</h4>
        <ul>
          <li>✨ Tips Belajar Bahasa Inggris Efektif</li>
          <li>📚 Cara Melatih Speaking Setiap Hari</li>
          <li>🚀 Belajar Vocabulary dengan AI</li>
        </ul>
      </div>
    </div>

    <!-- Formulir Percakapan -->
    <div id="chatForm" class="chat-form">
      <label>Email</label>
      <input type="email" placeholder="Masukkan email Anda" />

      <label>Nama Lengkap</label>
      <input type="text" placeholder="Masukkan nama lengkap Anda" />

      <label>Pilih Topik</label>
      <select>
        <option>Pilih Topik</option>
        <option>Belajar Dasar</option>
        <option>Kelas Menengah</option>
        <option>Kelas Lanjutan</option>
      </select>

      <label>Pesan</label>
      <textarea placeholder="Harap masukkan pesan Anda"></textarea>

      <div style="display: flex; gap: 10px">
        <button id="sendMsg">Kirim Pesan</button>
        <button id="backBtn" type="button" style="background: #6b7280">
          Kembali
        </button>
      </div>

      <div class="powered">⚙️ Powered by Chatwoot</div>
    </div>
  </div>
</div>

<!-- TOGGLE BUTTON -->
<button class="chat-toggle" id="chatToggle">
  <img
    src="https://cdn-icons-png.flaticon.com/512/134/134914.png"
    alt="Toggle Chat"
  />
</button>
`;
}

// simple behavior for chatbox (toggle)
document.addEventListener("click", (e) => {
  const toggle = e.target.closest && e.target.closest("#chat-toggle");
  const close = e.target.closest && e.target.closest("#chat-close");
  const send = e.target.closest && e.target.closest("#chat-send");
  if (toggle) {
    const panel = document.getElementById("chat-panel");
    if (!panel) return;
    panel.classList.remove("hidden");
    panel.setAttribute("aria-hidden", "false");
  }
  if (close) {
    const panel = document.getElementById("chat-panel");
    if (!panel) return;
    panel.classList.add("hidden");
    panel.setAttribute("aria-hidden", "true");
  }
  if (send) {
    const input = document.getElementById("chat-input");
    const messages = document.getElementById("chat-messages");
    if (!input || !messages) return;
    const v = input.value.trim();
    if (!v) return;
    messages.insertAdjacentHTML(
      "beforeend",
      `<div class="user-message">${v.replace(/</g, "&lt;")}</div>`
    );
    input.value = "";
    messages.scrollTop = messages.scrollHeight;
  }
});
