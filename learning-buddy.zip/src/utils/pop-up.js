// src/utils/popup.js
export function setupPopup() {
  /// open login
  document.getElementById("openLogin")?.addEventListener("click", () => {
    const popup = document.getElementById("popup-container");
    popup.classList.add("show"); // INI WAJIB
  });

  // open register
  document.getElementById("openRegister")?.addEventListener("click", () => {
    const popup = document.getElementById("popup-container");
    popup.classList.add("show"); // WAJIB
  });

  // close
  document.getElementById("closePopup")?.addEventListener("click", () => {
    document.getElementById("popup-container").classList.remove("show");
  });

  // login → register
  document.getElementById("toRegister")?.addEventListener("click", (e) => {
    e.preventDefault();
    document.getElementById("loginForm").classList.add("hidden");
    document.getElementById("registerForm").classList.remove("hidden");
  });

  // register → login
  document.getElementById("toLogin")?.addEventListener("click", (e) => {
    e.preventDefault();
    document.getElementById("registerForm").classList.add("hidden");
    document.getElementById("loginForm").classList.remove("hidden");
  });
}
