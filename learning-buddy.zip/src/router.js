// src/router.js
import Home, { hydrateHome } from "./pages/home.js";
import About from "./pages/about.js";
import Chat from "./pages/chat.js";
import Program from "./pages/program.js";

const routes = {
  "/": { view: Home, mount: hydrateHome },
  "/about": { view: About },
  "/chat": { view: Chat },
  "/program": { view: Program },
};

export function navigateTo(path) {
  history.pushState(null, null, path);
  router();
}

// function attachPopupEvents() {
//   // OPEN LOGIN
//   document.getElementById("openLogin")?.addEventListener("click", () => {
//     const popup = document.getElementById("popup-container");
//     if (!popup) return; // popup hanya ada di home
//     popup.classList.remove("hidden");

//     document.getElementById("loginForm")?.classList.remove("hidden");
//     document.getElementById("registerForm")?.classList.add("hidden");
//   });

//   // OPEN REGISTER
//   document.getElementById("openRegister")?.addEventListener("click", () => {
//     const popup = document.getElementById("popup-container");
//     if (!popup) return;
//     popup.classList.remove("hidden");

//     document.getElementById("loginForm")?.classList.add("hidden");
//     document.getElementById("registerForm")?.classList.remove("hidden");
//   });

//   // CLOSE
//   document.getElementById("closePopup")?.addEventListener("click", () => {
//     document.getElementById("popup-container")?.classList.add("hidden");
//   });

//   // SWITCH LOGIN → REGISTER
//   document.getElementById("toRegister")?.addEventListener("click", (e) => {
//     e.preventDefault();
//     document.getElementById("loginForm")?.classList.add("hidden");
//     document.getElementById("registerForm")?.classList.remove("hidden");
//   });

//   // SWITCH REGISTER → LOGIN
//   document.getElementById("toLogin")?.addEventListener("click", (e) => {
//     e.preventDefault();
//     document.getElementById("registerForm")?.classList.add("hidden");
//     document.getElementById("loginForm")?.classList.remove("hidden");
//   });
// }

export function router() {
  const path = window.location.pathname;
  const route = routes[path] || null;
  const app = document.getElementById("app");
  if (!app) return;

  if (!route) {
    app.innerHTML = `<h2 class="p-8 text-center">404 - Page Not Found</h2>`;
    return;
  }

  // render HTML (exact markup from page fn)
  app.innerHTML = route.view();
  // call mount/hydrate if provided
  if (route.mount && typeof route.mount === "function") {
    route.mount();
  }
}
