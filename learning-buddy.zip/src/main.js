// src/main.js
import { router, navigateTo } from "./router.js";
import { Navbar, initNavbarEvents } from "./components/navbar.js";
import { Footer } from "./components/footer.js";
import { ChatboxWidget } from "./components/chatbox.js";
import { setupPopup } from "./utils/pop-up.js";

window.addEventListener("DOMContentLoaded", () => {
  // render static layout
  document.getElementById("navbar").innerHTML = Navbar();
  document.getElementById("footer").innerHTML = Footer();
  document.body.insertAdjacentHTML("beforeend", ChatboxWidget());

  // init SPA nav
  initNavbarEvents();

  // render first page
  router();

  // ❗ popup AFTER router & navbar rendered
  setupPopup();

  // global navigateTo
  window.navigateTo = navigateTo;
});

window.addEventListener("popstate", router);
