// src/pages/program.js
export default function Program() {
  return `
  <main class="program-page section">
    <div class="container">
      <h2>Program</h2>
      <p>Daftar program dan detailnya akan tampil disini.</p>
      <div id="program-detail"></div>
    </div>
  </main>
  `;
}
