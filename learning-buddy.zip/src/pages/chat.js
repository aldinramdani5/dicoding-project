// src/pages/chat.js
export default function Chat() {
  return `<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Chat Assistant</title>
    <link rel="stylesheet" href="assets/css/style.css" />

    <style>
      body {
        background-color: #f4f6fa;
        font-family: "Segoe UI", Arial, sans-serif;
        display: flex;
        flex-direction: column;
        min-height: 100vh;
      }

      .chat-wrapper {
        display: flex;
        justify-content: center;
        align-items: center;
        flex: 1;
        padding: 40px 0;
      }

      .chat-page {
        width: 100%;
        max-width: 1100px;
        height: 85vh;
        background: #ffffff;
        border-radius: 18px;
        box-shadow: 0 6px 20px rgba(0, 0, 0, 0.15);
        overflow: hidden;
        display: flex;
        flex-direction: column;
        border: 1px solid #dcdcdc;
      }

      /* === Header === */
      .chat-header {
        background: #0078d7;
        color: #fff;
        padding: 18px 22px;
        display: flex;
        justify-content: space-between;
        align-items: center;
      }

      .chat-header h2 {
        font-size: 1.3rem;
        letter-spacing: 0.5px;
      }

      .chat-header a {
        color: #fff;
        font-size: 1.8rem;
        text-decoration: none;
        line-height: 1;
      }

      /* === Chat body === */
      .chat-body {
        flex: 1;
        padding: 18px;
        overflow-y: auto;
        background: #f9fafc;
        display: flex;
        flex-direction: column;
        gap: 12px;
        scroll-behavior: smooth;
      }

      .chat-message {
        max-width: 75%;
        padding: 12px 16px;
        border-radius: 14px;
        font-size: 1rem;
        line-height: 1.5;
        word-wrap: break-word;
      }

      .chat-message.bot {
        background: #e1ecf7;
        color: #333;
        align-self: flex-start;
        border-top-left-radius: 0;
      }

      .chat-message.user {
        background: #0078d7;
        color: #fff;
        align-self: flex-end;
        border-top-right-radius: 0;
      }

      /* === Chat input === */
      .chat-input {
        display: flex;
        border-top: 1px solid #ddd;
        background: #fff;
      }

      .chat-input input {
        flex: 1;
        padding: 14px;
        border: none;
        outline: none;
        font-size: 1rem;
      }

      .chat-input button {
        background: #0078d7;
        color: #fff;
        border: none;
        padding: 0 24px;
        cursor: pointer;
        transition: background 0.2s ease;
      }

      .chat-input button:hover {
        background: #005fa3;
      }
    </style>
  </head>

  <body>
    <div class="chat-wrapper">
      <div class="chat-page">
        <div class="chat-header">
          <h2>Chat Assistant</h2>
          <a href="index.html" title="Kembali ke Beranda">&times;</a>
        </div>

        <div class="chat-body" id="chatBody">
          <div class="chat-message bot">
            Halo! Selamat datang di layanan chat kami. Ada yang bisa dibantu?
          </div>
        </div>

        <div class="chat-input">
          <input type="text" id="userMessage" placeholder="Ketik pesan..." />
          <button id="sendMessage">Kirim</button>
        </div>
      </div>
    </div>

    <!-- Footer container -->
    <div id="footer-container">
      <footer>© 2025 Chat Assistant. All rights reserved.</footer>
    </div>

    <script>
      const sendMessage = document.getElementById("sendMessage");
      const userInput = document.getElementById("userMessage");
      const chatBody = document.getElementById("chatBody");

      sendMessage.addEventListener("click", () => {
        const msg = userInput.value.trim();
        if (msg) {
          const userMsg = document.createElement("div");
          userMsg.classList.add("chat-message", "user");
          userMsg.textContent = msg;
          chatBody.appendChild(userMsg);
          userInput.value = "";
          chatBody.scrollTop = chatBody.scrollHeight;

          // Simulasi respon bot
          setTimeout(() => {
            const botMsg = document.createElement("div");
            botMsg.classList.add("chat-message", "bot");
            botMsg.textContent =
              "Pesan kamu sudah diterima! Terima kasih telah menghubungi kami.";
            chatBody.appendChild(botMsg);
            chatBody.scrollTop = chatBody.scrollHeight;
          }, 800);
        }
      });
    </script>

    <!-- Panggil JS untuk load footer dinamis -->
    <script src="assets/js/footer.js"></script>
  </body>
</html>
`;
}
